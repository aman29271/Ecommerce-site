
         

    
    <footer> 
    <div class="container">   
        <div class="row">
            <div class="col-xs-4">
                <h3>Information</h3>
                <a href="../aboutus.php">About Us</a>
                <a href="../contactus.php">Contact Us</a>
            </div>
            <div class="col-xs-4">
                <h3>My Account</h3>
                <a href="../login1.php.php">LogIn</a>
                <a href="../signup1.php">Sign Up</a>
            </div>
            <div class="col-xs-4">
                <h3>Contact Us</h3>
                contact +91-123-0000000
            </div>
        </div>   
            
    </div>
    </footer>
 



