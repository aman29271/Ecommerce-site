<?php
$con= mysqli_connect("localhost", "root", "AMAN29271", "store") or
        die(mysqli_error($con));
session_start();



