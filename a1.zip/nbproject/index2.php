<?php
require 'includes/common.php';
?>
<html>
            <head>
                <title></title>
                <link href="bootstrap/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
                <script src="bootstrap/bootstrap/js/bootstrap.js" type="text/javascript"></script>
                <script src="bootstrap/jquery-3.2.1.min.js" type="text/javascript"></script>
                <style>
                    footer{
      background-color: #000; 
      color:#fff;   
      font-size:14px; 
 
}
                </style>
            </head>
    <body>
        <?php require 'includes/header_1.php';?>
        <div class="container-fluid">
            <div class="row">
                <div class="col-xs-4">
                    <div class="panel panel-primary">
                        <div class="panel-heading">Mobile 1</div>
                        <div class="panel-body"><center><a href="signup1.php" class="btn btn-primary btn-block">Add to Cart</a></center></div>
                        
                    </div>
                </div>
                <div class="col-xs-4">
                    <div class="panel panel-primary">
                        <div class="panel-heading">Mobile 2</div>
                        <div class="panel-body"><center><a href="signup1.php" class="btn btn-primary btn-block">Add to Cart</a></center></div>
                        
                    </div>
                </div>
                <div class="col-xs-4">
                    <div class="panel panel-primary">
                        <div class="panel-heading">Mobile 3</div>
                        <div class="panel-body"><center><a href="signup1.php" class="btn btn-primary btn-block">Add to Cart</a></center></div>
                        
                    </div>
                </div>
               
            </div>
            <div class="row">
                <div class="col-xs-4">
                    <div class="panel panel-primary">
                        <div class="panel-heading">Mobile 4</div>
                        <div class="panel-body"><center><a href="signup1.php" class="btn btn-primary btn-block">Add to Cart</a></center></div>
                        
                    </div>
                </div>
                <div class="col-xs-4">
                    <div class="panel panel-primary">
                        <div class="panel-heading">Mobile 5</div>
                        <div class="panel-body"><center><a href="signup1.php" class="btn btn-primary btn-block">Add to Cart</a></center></div>
                        
                    </div>
                </div>
                <div class="col-xs-4">
                    <div class="panel panel-primary">
                        <div class="panel-heading">Mobile 6</div>
                        <div class="panel-body"><center><a href="signup1.php" class="btn btn-primary btn-block">Add to Cart</a></center></div>
                       
                    </div>
                </div>
                
                </div>
            </div>
        <?php require 'includes/footer_1.php';?>
    </body>
</html>

